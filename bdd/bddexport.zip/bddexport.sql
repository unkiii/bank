-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.1.21-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win32
-- HeidiSQL Versión:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para bank
CREATE DATABASE IF NOT EXISTS `bank` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `bank`;

-- Volcando estructura para tabla bank.admin
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nif` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1_nif` (`nif`),
  CONSTRAINT `FK1_nif` FOREIGN KEY (`nif`) REFERENCES `clients` (`nif`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla bank.admin: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
REPLACE INTO `admin` (`id`, `nif`) VALUES
	(1, '123456789');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;

-- Volcando estructura para tabla bank.autoprogramats
CREATE TABLE IF NOT EXISTS `autoprogramats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dni` varchar(50) NOT NULL DEFAULT '0',
  `tasca` int(11) NOT NULL,
  `quantitat` int(11) NOT NULL DEFAULT '0',
  `dia` date NOT NULL,
  `hora` time NOT NULL,
  `realitzat` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK1_dni` (`dni`),
  KEY `FK2_tasca` (`tasca`),
  CONSTRAINT `FK1_dni` FOREIGN KEY (`dni`) REFERENCES `clients` (`nif`),
  CONSTRAINT `FK2_tasca` FOREIGN KEY (`tasca`) REFERENCES `tasquesautoprogramades` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla bank.autoprogramats: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `autoprogramats` DISABLE KEYS */;
REPLACE INTO `autoprogramats` (`id`, `dni`, `tasca`, `quantitat`, `dia`, `hora`, `realitzat`) VALUES
	(1, '123456789', 1, 50, '2017-09-27', '06:00:00', 1);
/*!40000 ALTER TABLE `autoprogramats` ENABLE KEYS */;

-- Volcando estructura para tabla bank.clients
CREATE TABLE IF NOT EXISTS `clients` (
  `numclient` int(11) NOT NULL AUTO_INCREMENT,
  `nif` varchar(50) NOT NULL DEFAULT '0',
  `pass` varchar(50) NOT NULL DEFAULT '0',
  `metalic` int(11) NOT NULL DEFAULT '1000',
  `nom` varchar(50) NOT NULL DEFAULT '0',
  `cognom` varchar(50) NOT NULL DEFAULT '0',
  `dataalta` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `direccio` varchar(50) NOT NULL DEFAULT '0',
  `poblacio` varchar(50) NOT NULL DEFAULT '0',
  `datanaix` varchar(50) NOT NULL DEFAULT '0',
  `cp` varchar(50) NOT NULL DEFAULT '0',
  `permis` int(11) DEFAULT '0',
  PRIMARY KEY (`numclient`,`nif`),
  KEY `nif` (`nif`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla bank.clients: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
REPLACE INTO `clients` (`numclient`, `nif`, `pass`, `metalic`, `nom`, `cognom`, `dataalta`, `direccio`, `poblacio`, `datanaix`, `cp`, `permis`) VALUES
	(1, '123456789', '1234', 800, 'Fran', 'Navi', '2017-09-25 10:25:17', 'c/ sinley', 'Balaguer', '18/11/1988', '25600', 0),
	(2, '112233', '1122', 450, 'Pepo', 'Nacleto', '2017-09-25 10:27:04', 'c/ olalà', 'Perdida', '01/09/2000', '57418', 0);
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;

-- Volcando estructura para tabla bank.comptes
CREATE TABLE IF NOT EXISTS `comptes` (
  `numcompte` int(11) NOT NULL,
  `saldo` int(11) NOT NULL DEFAULT '0',
  `clientassignat` int(11) NOT NULL,
  `tipus` int(11) NOT NULL,
  PRIMARY KEY (`numcompte`),
  KEY `FK1_client` (`clientassignat`),
  KEY `FK2_tipus` (`tipus`),
  CONSTRAINT `FK1_client` FOREIGN KEY (`clientassignat`) REFERENCES `clients` (`numclient`),
  CONSTRAINT `FK2_tipus` FOREIGN KEY (`tipus`) REFERENCES `llibretes` (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla bank.comptes: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `comptes` DISABLE KEYS */;
REPLACE INTO `comptes` (`numcompte`, `saldo`, `clientassignat`, `tipus`) VALUES
	(155123, 1003, 1, 3),
	(155687, 1001, 1, 1),
	(155789, 1002, 1, 2);
/*!40000 ALTER TABLE `comptes` ENABLE KEYS */;

-- Volcando estructura para tabla bank.facturacio
CREATE TABLE IF NOT EXISTS `facturacio` (
  `idfactura` int(11) DEFAULT NULL,
  `numclient` int(11) DEFAULT NULL,
  `data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `pagada` int(11) DEFAULT '0',
  KEY `FK1_num_client` (`numclient`),
  KEY `FK2_rebut` (`idfactura`),
  CONSTRAINT `FK1_num_client` FOREIGN KEY (`numclient`) REFERENCES `clients` (`numclient`),
  CONSTRAINT `FK2_rebut` FOREIGN KEY (`idfactura`) REFERENCES `rebuts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla bank.facturacio: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `facturacio` DISABLE KEYS */;
REPLACE INTO `facturacio` (`idfactura`, `numclient`, `data`, `pagada`) VALUES
	(1, 1, '2017-09-25 11:53:41', 0),
	(4, 1, '2017-10-04 10:33:58', 0),
	(2, 1, '2017-10-04 10:40:14', 0);
/*!40000 ALTER TABLE `facturacio` ENABLE KEYS */;

-- Volcando estructura para tabla bank.llibretes
CREATE TABLE IF NOT EXISTS `llibretes` (
  `num` int(11) NOT NULL,
  `tipus` varchar(50) DEFAULT NULL,
  `comissio` varchar(50) DEFAULT NULL,
  `interesos` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla bank.llibretes: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `llibretes` DISABLE KEYS */;
REPLACE INTO `llibretes` (`num`, `tipus`, `comissio`, `interesos`) VALUES
	(1, 'Compte Corrent', '2', '0'),
	(2, 'Compte Ahorro', '0', '1'),
	(3, 'Compte Pla Pensions', '0', '2');
/*!40000 ALTER TABLE `llibretes` ENABLE KEYS */;

-- Volcando estructura para tabla bank.rebuts
CREATE TABLE IF NOT EXISTS `rebuts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa` varchar(50) NOT NULL DEFAULT '0',
  `quantitat` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla bank.rebuts: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `rebuts` DISABLE KEYS */;
REPLACE INTO `rebuts` (`id`, `empresa`, `quantitat`) VALUES
	(1, 'aigua', 200),
	(2, 'llum', 300),
	(3, 'gas', 400),
	(4, 'hipoteca', 800),
	(5, 'vehicle', 500);
/*!40000 ALTER TABLE `rebuts` ENABLE KEYS */;

-- Volcando estructura para tabla bank.tasquesautoprogramades
CREATE TABLE IF NOT EXISTS `tasquesautoprogramades` (
  `id` int(11) NOT NULL,
  `accio` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla bank.tasquesautoprogramades: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `tasquesautoprogramades` DISABLE KEYS */;
REPLACE INTO `tasquesautoprogramades` (`id`, `accio`) VALUES
	(1, 'Transferencia de Compte corrent a Compte Estalvis'),
	(2, 'Transferencia de Compte Corrent a Compte Pla Pensi');
/*!40000 ALTER TABLE `tasquesautoprogramades` ENABLE KEYS */;

-- Volcando estructura para tabla bank.titular
CREATE TABLE IF NOT EXISTS `titular` (
  `numcompte` int(11) NOT NULL,
  `titular1` varchar(50) NOT NULL,
  `titular2` varchar(50) DEFAULT NULL,
  KEY `FK1_num_compte` (`numcompte`),
  KEY `FK2_titular1` (`titular1`),
  CONSTRAINT `FK1_num_compte` FOREIGN KEY (`numcompte`) REFERENCES `comptes` (`numcompte`),
  CONSTRAINT `FK2_titular1` FOREIGN KEY (`titular1`) REFERENCES `clients` (`nif`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla bank.titular: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `titular` DISABLE KEYS */;
REPLACE INTO `titular` (`numcompte`, `titular1`, `titular2`) VALUES
	(155687, '123456789', NULL),
	(155789, '123456789', NULL),
	(155123, '123456789', NULL);
/*!40000 ALTER TABLE `titular` ENABLE KEYS */;

-- Volcando estructura para tabla bank.traspassos
CREATE TABLE IF NOT EXISTS `traspassos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numenviat` int(11) DEFAULT NULL,
  `numrebut` int(11) DEFAULT NULL,
  `quantitat` int(11) DEFAULT NULL,
  `data` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla bank.traspassos: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `traspassos` DISABLE KEYS */;
/*!40000 ALTER TABLE `traspassos` ENABLE KEYS */;

-- Volcando estructura para tabla bank.zregistremovimients
CREATE TABLE IF NOT EXISTS `zregistremovimients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loclient` varchar(50) NOT NULL DEFAULT '0',
  `haFet` varchar(50) NOT NULL DEFAULT '0',
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Volcando datos para la tabla bank.zregistremovimients: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `zregistremovimients` DISABLE KEYS */;
REPLACE INTO `zregistremovimients` (`id`, `loclient`, `haFet`, `fecha`) VALUES
	(4, '123456789', 'Login', '2017-10-05 09:53:01'),
	(5, '123456789', 'Login', '2017-10-05 10:00:40'),
	(6, '123456789', 'Login', '2017-10-05 10:12:47'),
	(7, '123456789', 'Login', '2017-10-05 11:30:02');
/*!40000 ALTER TABLE `zregistremovimients` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
